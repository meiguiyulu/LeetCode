# [206. Reverse Linked List](https://leetcode.com/problems/reverse-linked-list/description/)

## 题目

Reverse a singly linked list.

## 题目大意

翻转单链表


## 解题思路

按照题意做即可。