# [203. Remove Linked List Elements](https://leetcode.com/problems/remove-linked-list-elements/)

## 题目

Remove all elements from a linked list of integers that have value val.

Example :

```c
Input:  1->2->6->3->4->5->6, val = 6
Output: 1->2->3->4->5
```


## 题目大意

删除链表中所有指定值的结点。

## 解题思路

按照题意做即可。